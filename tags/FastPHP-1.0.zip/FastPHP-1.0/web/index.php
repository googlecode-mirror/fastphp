<?php
require(dirname(__FILE__) . "/action.php");
