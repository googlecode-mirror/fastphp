<?php
require_once dirname(__FILE__)."/Mail/MAIL.php";
